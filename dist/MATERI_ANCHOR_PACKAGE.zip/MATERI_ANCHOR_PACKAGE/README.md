# MATERI ANCHOR PACKAGE — CORTEX-SHELL
## Systematic Work Guide for AI Agents (Lecture Module Generation)
### Version: 1.0 | Date: 2026-06-10

---

## WHAT IS THIS PACKAGE?

This package contains EVERYTHING an AI agent needs to correctly process raw lecture PDF slides
and generate production-ready `module.json` files for the CORTEX-SHELL medical education platform.

Send this entire package alongside your raw PDF files to the content agent.

---

## FILE STRUCTURE

```
MATERI_ANCHOR_PACKAGE/
├── README.md                          ← You are here. Read this first.
├── CONTENT_SCHEMA_MASTER.md           ← MASTER schema reference (all fields, all rules)
│
├── packages_materi/
│   ├── PROMPT_MATERI_VISION_AGENT.md  ← Main prompt to paste into the agent
│   ├── SCHEMA_MODULE_JSON_REFERENCE.md ← Detailed module.json field documentation
│   ├── OCR_VISION_PROTOCOL.md         ← Mandatory per-page OCR + Vision protocol
│   ├── VISUAL_MAPPING_GUIDE.md        ← How to classify and ID visual assets
│   ├── BATCH_PROCESSING_GUIDE.md      ← 10-PDF max batching, section ID allocation
│   ├── CONTENT_RATIO_PROTOCOL.md      ← 60/40 source vs AI-researched content rules
│   └── OUTPUT_VALIDATION_CHECKLIST.md ← 9-section QA gate before submitting output
│
├── packages_shared/
│   ├── CONTENT_INDEX_REGISTRY_GUIDE.md ← How to add module to content_index.kimi.json
│   ├── VISUAL_ASSET_MANIFEST_GUIDE.md  ← How to add visual assets to manifest
│   ├── COMPILE_AUDIT_GUIDE.md          ← Multi-batch compilation and audit report format
│   └── APP_INTEGRATION_CHECKLIST.md    ← Final 8-section integration gate
│
├── example_module/
│   └── mod_neuro_stroke_001/
│       ├── module.json                 ← GROUND TRUTH: Complete example output (11 sections)
│       ├── content.md                  ← Supplementary content document
│       └── metadata.json              ← Module metadata
│
└── runtime_data/
    ├── content_index.kimi.json         ← Current live content registry
    └── visual_asset_manifest.generated.json ← Current visual asset registry
```

---

## HOW TO USE THIS PACKAGE

### Step 1 — Read the master schema
Open `CONTENT_SCHEMA_MASTER.md` first. This defines every field, every rule.

### Step 2 — Study the ground truth example
Open `example_module/mod_neuro_stroke_001/module.json`. This is a complete, validated
production module. Your output must match this structure exactly.

### Step 3 — Copy the agent prompt
Open `packages_materi/PROMPT_MATERI_VISION_AGENT.md`. Copy the entire prompt.
Paste it as the system prompt or first message to your content agent.

### Step 4 — Send PDFs with protocol
Also share `packages_materi/OCR_VISION_PROTOCOL.md` with the agent.
This ensures every page (including pure-image pages) is processed with Vision.

### Step 5 — Validate output
After the agent generates module.json, run through `packages_materi/OUTPUT_VALIDATION_CHECKLIST.md`.
Then follow `packages_shared/CONTENT_INDEX_REGISTRY_GUIDE.md` to register the new module.

---

## CRITICAL RULES (SUMMARY)

1. **Max 10 PDFs per batch** — If you have more, split into multiple batches
2. **Type C PDFs (pure image)** — Always use Vision, never assume OCR text extraction works
3. **Content ratio** — 60% from source PDFs, 40% AI-researched supplements
4. **Callout tones** — Only: `pearl`, `evidence`, `note`, `caution`, `danger`
5. **answer_index** — 0-based integer (0–3), never a letter
6. **Register output** — Always update `content_index.kimi.json` after generating

---

## OUTPUT DESTINATION

Generated `module.json` files go to:
```
app_data/domains/materi/modules/[module_id]/module.json
```

Then register in:
```
app_data/runtime/content_index.kimi.json
app_data/runtime/visual_asset_manifest.generated.json
```
