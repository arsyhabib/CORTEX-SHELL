#!/usr/bin/env python3
"""
orchestrate_all.py — MAIN ENTRY POINT.
Orchestrates generation of all 54 visuals in parallel batches.
This is the script the agent calls first.

Usage:
  python3 orchestrate_all.py --api-key YOUR_KEY
  python3 orchestrate_all.py --api-key YOUR_KEY --batch 1  (run specific batch only)
  python3 orchestrate_all.py --dry-run                     (test without API calls)
  python3 orchestrate_all.py --parallel 10                 (max parallel workers)
"""
import json, sys, os, argparse, subprocess
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

BASE = Path(__file__).parent.parent

def load_manifest():
    with open(BASE / 'config/generation_manifest.json') as f:
        return json.load(f)

def run_single_visual(task, api_key, dry_run=False):
    """Run generate_single_visual.py for one task"""
    cmd = [sys.executable, str(BASE / 'scripts/generate_single_visual.py'),
           task['visual_id'], '--output-format', 'json']
    if api_key: cmd.extend(['--api-key', api_key])
    if dry_run: cmd.append('--dry-run')
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
        output = result.stdout.strip()
        # Parse last JSON line
        for line in reversed(output.split('\n')):
            if line.startswith('{'):
                return json.loads(line)
        return {'visual_id': task['visual_id'], 'status': 'error', 'error': result.stderr[:200]}
    except subprocess.TimeoutExpired:
        return {'visual_id': task['visual_id'], 'status': 'timeout'}
    except Exception as e:
        return {'visual_id': task['visual_id'], 'status': 'error', 'error': str(e)}

def main():
    parser = argparse.ArgumentParser(description='Orchestrate all 54 visual generations')
    parser.add_argument('--api-key',  '-k', default=os.environ.get('OPENAI_API_KEY', ''))
    parser.add_argument('--batch',    '-b', type=int, default=None, help='Run specific batch (1-6)')
    parser.add_argument('--parallel', '-p', type=int, default=10,   help='Max parallel workers')
    parser.add_argument('--dry-run',        action='store_true')
    parser.add_argument('--resume',         action='store_true',    help='Skip already-generated visuals')
    args = parser.parse_args()

    manifest = load_manifest()
    all_tasks = manifest['task_index']
    
    # Filter by batch if specified
    tasks = [t for t in all_tasks if args.batch is None or t['batch'] == args.batch]
    
    # Resume: skip already-generated
    if args.resume:
        remaining = []
        for t in tasks:
            infographic = BASE / 'semi_finished_output' / t['module_id'] / 'assets' / f"{t['visual_id']}_infographic.png"
            if not infographic.exists():
                remaining.append(t)
        print(f"Resume mode: {len(tasks)} total, {len(tasks)-len(remaining)} already done, {len(remaining)} remaining")
        tasks = remaining
    
    print(f"\n🚀 CORTEX-SHELL Visual Generation Orchestrator")
    print(f"   Tasks: {len(tasks)} visuals × 3 outputs = {len(tasks)*3} images")
    print(f"   Parallel workers: {min(args.parallel, len(tasks))}")
    print(f"   Dry run: {args.dry_run}\n")

    if not args.api_key and not args.dry_run:
        print("ERROR: Set OPENAI_API_KEY or use --api-key", file=sys.stderr); sys.exit(1)

    completed = failed = 0
    results_log = []

    with ThreadPoolExecutor(max_workers=min(args.parallel, len(tasks))) as executor:
        futures = {executor.submit(run_single_visual, t, args.api_key, args.dry_run): t for t in tasks}
        
        for future in as_completed(futures):
            task   = futures[future]
            result = future.result()
            status = result.get('status', 'unknown')
            
            if status == 'complete':
                completed += 1
                print(f"  ✅ [{completed+failed}/{len(tasks)}] {task['visual_id']}")
            else:
                failed += 1
                print(f"  ❌ [{completed+failed}/{len(tasks)}] {task['visual_id']} — {status}: {result.get('error', '')[:80]}")
            
            results_log.append({**result, 'task_id': task['task_id'], 'batch': task['batch']})

    print(f"\n=== GENERATION COMPLETE ===")
    print(f"✅ Success: {completed}/{len(tasks)}")
    print(f"❌ Failed:  {failed}/{len(tasks)}")
    
    # Save log
    log_path = BASE / 'config/GENERATION_LOG.json'
    with open(log_path, 'w') as f:
        json.dump({'summary': {'completed': completed, 'failed': failed, 'total': len(tasks)},
                   'results': results_log}, f, indent=2)
    print(f"\nLog saved: {log_path}")
    
    # Auto-run post-processing if all complete
    if failed == 0:
        print("\n▶ Running post-processing...")
        subprocess.run([sys.executable, str(BASE / 'scripts/update_status.py')])
        subprocess.run([sys.executable, str(BASE / 'scripts/finalize_manifest.py')])
        subprocess.run([sys.executable, str(BASE / 'scripts/validate_completion.py')])
        print("\n✅ All done! Check config/COMPLETION_REPORT.json")
    else:
        print(f"\n⚠️  {failed} failures. Fix and re-run with --resume flag.")
    
    return 0 if failed == 0 else 1

if __name__ == '__main__':
    sys.exit(main())
