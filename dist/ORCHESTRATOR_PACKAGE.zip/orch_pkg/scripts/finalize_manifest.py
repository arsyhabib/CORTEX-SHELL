#!/usr/bin/env python3
"""
finalize_manifest.py — Updates config/visual_manifest_updated.json
based on which images actually exist. Run after update_status.py.
"""
import json
from pathlib import Path

BASE     = Path(__file__).parent.parent
MANIFEST = BASE / 'config/visual_manifest_updated.json'

with open(MANIFEST) as f:
    manifest = json.load(f)

generated = partial = missing = 0
for v in manifest['visual_assets']:
    outputs   = v['generation_outputs']
    all_exist = all((BASE.parent.parent / info['path']).exists() for info in outputs.values())
    any_exist = any((BASE.parent.parent / info['path']).exists() for info in outputs.values())

    if all_exist:
        v['status'] = 'generated'
        for info in outputs.values(): info['generated'] = True
        generated += 1
    elif any_exist:
        v['status'] = 'partial'
        partial += 1
    else:
        v['status'] = 'pending'
        missing  += 1

manifest['status_summary'] = {'generated': generated, 'partial': partial, 'pending': missing}
with open(MANIFEST, 'w') as f:
    json.dump(manifest, f, indent=2, ensure_ascii=False)
print(f"✅ Manifest updated: {generated} generated, {partial} partial, {missing} pending")
