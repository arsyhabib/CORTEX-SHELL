#!/usr/bin/env python3
"""
validate_completion.py — Verify all 54×3=162 images exist and are valid.
Produces a completion report. Run after all generation is done.
"""
import json, os
from pathlib import Path

BASE       = Path(__file__).parent.parent
MANIFEST   = BASE / 'config/visual_manifest_updated.json'
REPORT_OUT = BASE / 'config/COMPLETION_REPORT.json'

with open(MANIFEST) as f:
    manifest = json.load(f)

results = {"total": 0, "complete": 0, "partial": 0, "missing": 0, "failed": [], "complete_list": []}

for v in manifest['visual_assets']:
    vid     = v['id']
    outputs = v['generation_outputs']
    results['total'] += 1

    checks = {}
    for output_type, info in outputs.items():
        path = BASE.parent.parent / info['path']
        exists = path.exists()
        size_ok = path.stat().st_size > 50 * 1024 if exists else False
        checks[output_type] = {'exists': exists, 'size_ok': size_ok, 'path': info['path']}

    all_ok = all(c['exists'] and c['size_ok'] for c in checks.values())
    any_ok = any(c['exists'] for c in checks.values())

    if all_ok:
        results['complete'] += 1
        results['complete_list'].append(vid)
        print(f"  ✅ {vid}")
    elif any_ok:
        results['partial'] += 1
        missing = [t for t, c in checks.items() if not c['exists']]
        results['failed'].append({'id': vid, 'status': 'partial', 'missing': missing})
        print(f"  ⚠️  {vid} — missing: {missing}")
    else:
        results['missing'] += 1
        results['failed'].append({'id': vid, 'status': 'not_generated'})
        print(f"  ❌ {vid} — not generated")

completion_pct = (results['complete'] / results['total'] * 100) if results['total'] else 0

print(f"\n=== COMPLETION REPORT ===")
print(f"Total:     {results['total']} visuals ({results['total']*3} images)")
print(f"Complete:  {results['complete']} ({completion_pct:.1f}%)")
print(f"Partial:   {results['partial']}")
print(f"Missing:   {results['missing']}")

with open(REPORT_OUT, 'w') as f:
    json.dump({**results, 'completion_pct': round(completion_pct, 1)}, f, indent=2)
print(f"\nReport saved: {REPORT_OUT}")
