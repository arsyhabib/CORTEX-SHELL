#!/usr/bin/env python3
"""
generate_single_visual.py — Sub-agent script: generates 3 images for ONE visual.
Called by orchestrator for each of 54 visuals.

Usage: python3 generate_single_visual.py <visual_id> [--api-key KEY]

This script:
1. Loads ultra_prompt.json for the visual
2. Builds 3 specialized prompts (infographic, diagram, concept_map)
3. Calls DALL-E 3 (or configured model) for each
4. Saves outputs to pre-defined paths
5. Returns JSON status
"""
import json, sys, os, time, argparse
from pathlib import Path

BASE = Path(__file__).parent.parent

def load_visual_context(visual_id):
    pkg_dir = BASE / f"visual_packages_54/{visual_id}"
    prompt_file = pkg_dir / f"{visual_id}_ultra_prompt.json"
    ctx_file    = pkg_dir / f"{visual_id}_context.json"
    
    with open(prompt_file) as f: prompt_data = json.load(f)
    ctx = {}
    if ctx_file.exists():
        with open(ctx_file) as f: ctx = json.load(f)
    return prompt_data, ctx

def build_image_prompts(prompt_data, ctx):
    """Build 3 specialized DALL-E prompts from the ultra prompt JSON"""
    topic         = prompt_data['medical_context']['topic']
    visual_type   = prompt_data['medical_context'].get('visual_type', 'diagram')
    key_concepts  = prompt_data.get('content_to_illustrate', {}).get('key_concepts', [])[:3]
    concepts_str  = '; '.join(key_concepts) if key_concepts else 'geriatric medicine concepts'
    references    = ['Harrison\'s', 'Gray\'s Anatomy', 'WHO Guidelines']

    base_style = (
        "Medical education illustration, clean professional style, "
        "clinical accuracy, clear labels, consistent purple-teal-green color scheme. "
        "White or light background. Suitable for medical textbook."
    )

    return {
        'infographic': (
            f"Medical education INFOGRAPHIC about: {topic}. "
            f"Key information: {concepts_str}. "
            f"Design: grid layout with icons, statistics, and clear labels. "
            f"Include 4-6 key facts with visual icons. Color-coded sections. "
            f"Title prominent at top. Data accurate per {references[0]}. "
            f"{base_style} Size: landscape/wide format."
        ),
        'diagram': (
            f"Detailed medical DIAGRAM illustrating: {topic}. "
            f"Show anatomical/physiological structure with labeled components. "
            f"Include directional arrows showing processes or flows. "
            f"Clinical accuracy per {references[1]}. "
            f"Color-coded anatomical systems. All labels in clinical terminology. "
            f"{base_style}"
        ),
        'concept_map': (
            f"Medical CONCEPT MAP / mind map for: {topic}. "
            f"Hierarchical structure: central node with 3-5 branches. "
            f"Each branch: 2-4 sub-concepts. Connections labeled (causes, leads to, includes, etc.). "
            f"Simple node shapes (rectangles/ovals). "
            f"Color-coded by category (risks=red, mechanisms=blue, management=green). "
            f"Maximum 4 levels of depth. Clean and scannable. "
            f"{base_style}"
        )
    }

def get_output_paths(visual_id, prompt_data):
    """Get pre-defined output paths from manifest"""
    module_id  = prompt_data['medical_context']['module']
    assets_dir = BASE / f"semi_finished_output/{module_id}/assets"
    assets_dir.mkdir(parents=True, exist_ok=True)
    return {
        'infographic': assets_dir / f"{visual_id}_infographic.png",
        'diagram':     assets_dir / f"{visual_id}_diagram.png",
        'concept_map': assets_dir / f"{visual_id}_concept_map.png",
    }

def generate_with_dalle(prompt, output_path, api_key, config, output_type):
    """Call OpenAI DALL-E API to generate one image"""
    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
        
        size = config['image_generation'][f'size_{output_type}'] if f'size_{output_type}' in config['image_generation'] else '1024x1024'
        
        response = client.images.generate(
            model   = config['image_generation']['primary_model'],
            prompt  = prompt,
            n       = 1,
            size    = size,
            quality = config['image_generation']['quality'],
            style   = config['image_generation']['style'],
        )
        
        image_url = response.data[0].url
        
        import urllib.request
        urllib.request.urlretrieve(image_url, output_path)
        
        return {'success': True, 'path': str(output_path), 'size': os.path.getsize(output_path)}
    
    except ImportError:
        return {'success': False, 'error': 'openai package not installed. Run: pip install openai'}
    except Exception as e:
        return {'success': False, 'error': str(e)}

def main():
    parser = argparse.ArgumentParser(description='Generate 3 images for one visual')
    parser.add_argument('visual_id',             help='Visual ID to generate')
    parser.add_argument('--api-key', '-k',       default=os.environ.get('OPENAI_API_KEY', ''))
    parser.add_argument('--dry-run',             action='store_true')
    parser.add_argument('--output-format',       choices=['json', 'text'], default='text')
    args = parser.parse_args()

    if not args.api_key and not args.dry_run:
        print("ERROR: OPENAI_API_KEY not set. Use --api-key or set env var.", file=sys.stderr)
        sys.exit(1)

    print(f"\n📸 Generating: {args.visual_id}")
    
    # Load config
    config_path = BASE / 'config/generation_config.json'
    with open(config_path) as f:
        config = json.load(f)
    
    # Load context
    try:
        prompt_data, ctx = load_visual_context(args.visual_id)
    except FileNotFoundError as e:
        print(f"ERROR: {e}", file=sys.stderr); sys.exit(1)
    
    # Build prompts
    prompts       = build_image_prompts(prompt_data, ctx)
    output_paths  = get_output_paths(args.visual_id, prompt_data)
    
    results = {}
    for output_type in ['infographic', 'diagram', 'concept_map']:
        out_path = output_paths[output_type]
        
        if args.dry_run:
            out_path.touch()
            results[output_type] = {'success': True, 'path': str(out_path), 'dry_run': True}
            print(f"  [DRY-RUN] ✅ {output_type}: {out_path.name}")
            continue
        
        print(f"  Generating {output_type}...", end=' ', flush=True)
        retry_count = config['agent_settings']['retry_on_failure']
        
        for attempt in range(retry_count):
            result = generate_with_dalle(prompts[output_type], out_path, args.api_key, config, output_type)
            if result['success']:
                print(f"✅ ({result.get('size', 0)//1024}KB)")
                results[output_type] = result
                break
            else:
                if attempt < retry_count - 1:
                    print(f"⚠️ Retry {attempt+1}/{retry_count}...", end=' ', flush=True)
                    time.sleep(config['agent_settings']['retry_delay_sec'])
                else:
                    print(f"❌ FAILED: {result['error']}")
                    results[output_type] = result
    
    status = 'complete' if all(r.get('success') for r in results.values()) else 'partial'
    print(f"\n  Status: {status.upper()}")
    
    if args.output_format == 'json':
        print(json.dumps({'visual_id': args.visual_id, 'status': status, 'results': results}))
    
    return 0 if status == 'complete' else 1

if __name__ == '__main__':
    sys.exit(main())
