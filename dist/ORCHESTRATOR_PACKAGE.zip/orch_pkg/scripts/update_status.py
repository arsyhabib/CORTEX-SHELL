#!/usr/bin/env python3
"""
update_status.py — Run AFTER images are generated.
Scans asset directories, marks generated visuals as 'generated' in module.json files.
Usage: python3 update_status.py [--dry-run]
"""
import json, os, sys
from pathlib import Path

DRY_RUN = '--dry-run' in sys.argv
BASE = Path(__file__).parent.parent

MODULES = {
    'mod_geriatrics_001':        BASE / 'semi_finished_output/mod_geriatrics_001',
    'mod_geriatrics_klinis_001': BASE / 'semi_finished_output/mod_geriatrics_klinis_001',
}

total_updated = 0
total_missing = 0

for mod_id, mod_dir in MODULES.items():
    module_json_path = mod_dir / 'module.json'
    assets_dir       = mod_dir / 'assets'

    if not module_json_path.exists():
        print(f"⚠️  Missing: {module_json_path}"); continue

    with open(module_json_path) as f:
        module = json.load(f)

    updated = False
    for v in module.get('visual_asset_manifest', []):
        vid        = v['id']
        infographic = assets_dir / f"{vid}_infographic.png"
        diagram     = assets_dir / f"{vid}_diagram.png"
        concept_map = assets_dir / f"{vid}_concept_map.png"

        all_exist = infographic.exists() and diagram.exists() and concept_map.exists()
        any_exist = infographic.exists() or diagram.exists() or concept_map.exists()

        if all_exist and v.get('status') != 'generated':
            print(f"  ✅ {vid} — all 3 outputs present → GENERATED")
            if not DRY_RUN:
                v['status']           = 'generated'
                v['needs_generation'] = False
                v['src']              = str(infographic.relative_to(BASE.parent.parent))
                v['src_diagram']      = str(diagram.relative_to(BASE.parent.parent))
                v['src_concept_map']  = str(concept_map.relative_to(BASE.parent.parent))
            total_updated += 1
            updated = True
        elif any_exist and not all_exist:
            missing = [x.name for x in [infographic, diagram, concept_map] if not x.exists()]
            print(f"  ⚠️  {vid} — partial ({', '.join(missing)} missing)")
            total_missing += 1
        elif not any_exist:
            print(f"  ⏳ {vid} — not yet generated")
            total_missing += 1

    if updated and not DRY_RUN:
        with open(module_json_path, 'w') as f:
            json.dump(module, f, indent=2, ensure_ascii=False)
        print(f"\n✅ Saved {module_json_path.name}\n")

print(f"\n=== SUMMARY ===")
print(f"Updated to 'generated': {total_updated}")
print(f"Still missing:          {total_missing}")
if DRY_RUN:
    print("DRY RUN — no files written")
