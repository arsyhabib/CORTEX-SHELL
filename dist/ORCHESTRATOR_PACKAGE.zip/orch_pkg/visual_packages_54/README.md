# BATCH 6 — 54 Visual Generation Packages for GPT Thinking Mode
## Medical Education Illustration System
### Version: 1.0 | Date: 2026-06-10

---

## OVERVIEW

This package contains **54 individual visual generation packages** for CORTEX-SHELL geriatrics modules:
- **24 visuals** from `mod_geriatrics_001` (Comprehensive Geriatric Medicine)
- **30 visuals** from `mod_geriatrics_klinis_001` (Clinical Geriatrics & Emergencies)

Each package is optimized for **GPT-4 thinking mode** to generate **3 coordinated outputs per visual**:
1. **Infographic** — Summary with facts, statistics, icons
2. **Realistic Diagram** — Anatomical/physiological detailed illustration
3. **Concept Map** — Hierarchical mind-map

---

## PACKAGE STRUCTURE

```
Each visual has its own directory containing:

visual_[id]/
├── [id]_ultra_prompt.json          ← JSON-structured ultra prompt for GPT thinking
├── [id]_quality_checklist.md       ← QA gates for generated outputs
└── [id]_context.json               ← Medical context, references, glossary terms
```

### Example: visual_geriatric_aging_overview_01/
```
visual_geriatric_aging_overview_01/
├── visual_geriatric_aging_overview_01_ultra_prompt.json
├── visual_geriatric_aging_overview_01_quality_checklist.md
└── visual_geriatric_aging_overview_01_context.json
```

---

## HOW TO USE (Workflow)

### Step 1 — Extract Package
```bash
unzip BATCH_6_VISUAL_GENERATION_PACKAGES.zip
cd visual_packages_54/
```

### Step 2 — For Each Visual (54 iterations)
```bash
# 1. Load the ultra prompt
cat visual_geriatric_aging_overview_01/visual_geriatric_aging_overview_01_ultra_prompt.json

# 2. Convert JSON to readable prompt format (see conversion template below)

# 3. Send to GPT-4 with thinking mode enabled:
#    - System prompt: BATCH_6_ULTRA_PROMPT_FRAMEWORK.md content
#    - User message: [ultra_prompt.json expanded to text]
#    - Temperature: 1 (for creative visual design)
#    - Thinking budget: 8000-16000 tokens per visual

# 4. Save 3 output files:
#    visual_geriatric_aging_overview_01_infographic.svg
#    visual_geriatric_aging_overview_01_diagram.svg
#    visual_geriatric_aging_overview_01_concept_map.svg

# 5. Validate against quality checklist:
cat visual_geriatric_aging_overview_01/visual_geriatric_aging_overview_01_quality_checklist.md

# 6. Update module.json: status "pending" → "generated", set src path
```

### Step 3 — Batch Submission (if using API/CLI)
Use `batch_submission_template.json` to send all 54 in parallel or batch mode.

### Step 4 — Compile Results
All generated SVG files go to:
```
app_data/domains/materi/modules/mod_geriatrics_001/assets/
app_data/domains/materi/modules/mod_geriatrics_klinis_001/assets/
```

---

## ULTRA PROMPT JSON STRUCTURE

Each `[id]_ultra_prompt.json` contains:

```json
{
  "prompt_id": "visual_id",
  "system_instructions": { ... },
  "medical_context": {
    "topic": "Clinical topic",
    "section_id": "s01",
    "module": "mod_name"
  },
  "content_to_illustrate": {
    "key_concepts": ["concept1", "concept2", ...],
    "glossary_terms": ["term1", "term2", ...],
    "clinical_focus": "..."
  },
  "output_specifications": {
    "infographic": {...},
    "realistic_diagram": {...},
    "concept_map": {...}
  },
  "requirements": {
    "deliverables": [3 output specs],
    "quality_gates": [...],
    "reference_standards": [...]
  },
  "thinking_instructions": {
    "phase_1": "Research",
    "phase_2": "Identify objectives",
    ...,
    "time_allocation": "50% on thinking"
  }
}
```

---

## JSON-TO-TEXT CONVERSION (for manual submission)

To convert JSON ultra prompt to readable text for GPT:

```python
import json

# Load JSON
with open('visual_id_ultra_prompt.json') as f:
    prompt_data = json.load(f)

# Build text prompt
output = f"""
MEDICAL TOPIC: {prompt_data['medical_context']['topic']}
SECTION: {prompt_data['medical_context']['section_id']}
AUDIENCE: {prompt_data['medical_context']['audience']}

KEY CONCEPTS TO ILLUSTRATE:
{json.dumps(prompt_data['content_to_illustrate']['key_concepts'], indent=2)}

GLOSSARY TERMS (use for accurate labeling):
{json.dumps(prompt_data['content_to_illustrate']['glossary_terms'], indent=2)}

OUTPUT SPECIFICATIONS:
{json.dumps(prompt_data['output_specifications'], indent=2)}

QUALITY GATES (mandatory):
{json.dumps(prompt_data['requirements']['quality_gates'], indent=2)}

REFERENCE STANDARDS:
{json.dumps(prompt_data['requirements']['reference_standards'], indent=2)}

THINKING INSTRUCTIONS:
Use thinking mode to research topic, plan outputs, verify accuracy.
Allocate 50% of effort to thinking phase.
"""

print(output)
```

---

## QUALITY GATES (CRITICAL)

Every generated visual must pass ALL gates in its quality_checklist.md:

### Infographic Gates
- [ ] Statistics accurate per references
- [ ] No undefined clinical jargon
- [ ] Icons medically accurate
- [ ] Color contrast WCAG AA
- [ ] Clear text hierarchy

### Realistic Diagram Gates
- [ ] Anatomical accuracy (Gray's Anatomy / Harrison's)
- [ ] All labels present and spelled correctly
- [ ] Color coding per medical convention
- [ ] Proportions match human physiology
- [ ] Legends complete

### Concept Map Gates
- [ ] Logical hierarchical structure
- [ ] Connections clearly labeled
- [ ] Relationships clinically accurate
- [ ] Appropriate depth
- [ ] No isolated nodes

### Cross-Output Gates
- [ ] Consistent terminology across 3 outputs
- [ ] Complementary (not redundant) information
- [ ] Unified color scheme
- [ ] Professional medical education appearance

---

## REFERENCE MATERIALS

All visuals must be accurate per:
- **Gray's Anatomy** — Anatomical accuracy standard
- **Harrison's Principles of Internal Medicine** — Clinical content
- **WHO Guidelines on Integrated Care** — Geriatric best practices
- **American Geriatrics Society Standards** — Clinical guidelines
- **Brocklehurst's Textbook of Geriatric Medicine** — Specialty reference

---

## VISUAL TYPE MAPPING

| Type | Count | Output Focus |
|------|-------|--------------|
| Infographic | 13 | Key facts, statistics, prevention |
| Diagram | 15 | Anatomical/physiological structures |
| Flowchart | 7 | Clinical algorithms, decision-making |
| Reference Card | 5 | Quick-reference protocols, scoring |
| Anatomy | 4 | Organ system aging changes |
| Chart | 2 | Data visualization |
| Comparison | 4 | Side-by-side analysis |
| Timeline | 2 | Progression sequences |
| Algorithm | 1 | Diagnostic/management pathway |
| Anatomy 3D | 1 | 3D concept visualization |

---

## ESTIMATED TIMELINE

**Total: 54 visuals × 5-10 min thinking per visual = 5-9 hours**

Recommendations:
- **Fast track**: Use GPT API batch mode (parallel processing) → 2-3 hours
- **Standard**: Sequential submission via UI → 6-8 hours
- **Quality-focused**: Manual review between submissions → 8-10 hours

---

## OUTPUT FILE NAMING CONVENTION

All generated files follow:
```
[visual_id]_[output_type].[format]

Examples:
  visual_geriatric_aging_overview_01_infographic.svg
  visual_geriatric_aging_overview_01_diagram.svg
  visual_geriatric_aging_overview_01_concept_map.svg
```

---

## INTEGRATION INTO MODULE.JSON

After all 54 visuals are generated:

1. **Move SVG files** to appropriate module assets directories
2. **Update module.json** for each visual:
   ```json
   {
     "id": "visual_geriatric_aging_overview_01",
     "status": "generated",        ← changed from "pending"
     "src": "app_data/domains/materi/modules/mod_geriatrics_klinis_001/assets/visual_geriatric_aging_overview_01_infographic.svg",
     ...
   }
   ```
3. **Re-validate** via VALIDATION_REPORT.py
4. **Deploy** to production

---

## TROUBLESHOOTING

### "Infographic looks like diagram"
→ Ensure output_specifications were followed. Infographic should be high-level facts + icons, not detailed anatomy.

### "Color scheme inconsistent across outputs"
→ All 3 outputs must use same color palette. Check color_scheme in medical_context.

### "Medical terminology incorrect"
→ Verify against glossary_terms in context.json and reference_standards listed.

### "Concept map is too complex"
→ Limit to 3-4 hierarchy levels. Remove non-essential nodes.

---

## SUPPORT & VALIDATION

- **Question about output specs?** → See BATCH_6_ULTRA_PROMPT_FRAMEWORK.md
- **Schema compliance?** → Cross-check with CONTENT_SCHEMA_MASTER.md
- **Medical accuracy?** → Compare against reference_standards in each prompt

---

**Generated by**: CORTEX-SHELL Batch 6 Visual Framework  
**For**: GPT-4 Thinking Mode  
**Packages**: 54 (mod_geriatrics_001 × 24 + mod_geriatrics_klinis_001 × 30)  
**Output**: SVG infographics, realistic diagrams, concept maps
