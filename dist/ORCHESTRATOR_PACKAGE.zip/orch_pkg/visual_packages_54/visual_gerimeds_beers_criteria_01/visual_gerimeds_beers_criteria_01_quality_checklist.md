# Quality Checklist for visual_gerimeds_beers_criteria_01

## Pre-Generation
- [ ] Reviewed section context and key concepts
- [ ] Verified glossary terms and definitions
- [ ] Confirmed reference materials available
- [ ] Approved clinical focus and learning objectives

## Infographic Quality Gates
- [ ] All statistics accurate per references
- [ ] No undefined clinical jargon
- [ ] Icons clinically recognizable and accurate
- [ ] Color contrast passes WCAG AA standards
- [ ] Text hierarchy clear (title > headers > body)
- [ ] Layout uncluttered and easy to scan

## Realistic Diagram Quality Gates
- [ ] Anatomical accuracy per Gray's Anatomy / clinical standard
- [ ] All labels present and spelled correctly
- [ ] Color coding consistent with medical convention
- [ ] Proportions match human physiology
- [ ] Legends/keys complete and clear
- [ ] Scale references present (for anatomical drawings)

## Concept Map Quality Gates
- [ ] Hierarchical structure logical and complete
- [ ] Connections clearly labeled (causes, related to, divided into, etc.)
- [ ] No isolated nodes or orphaned concepts
- [ ] Relationships clinically accurate
- [ ] Appropriate depth (not oversimplified, not overwhelming)
- [ ] Visual hierarchy evident (size/position communicates importance)

## Cross-Output Consistency
- [ ] Same medical terminology across all 3 outputs
- [ ] Complementary information (no redundancy)
- [ ] Unified color scheme
- [ ] Consistent label naming and abbreviations
- [ ] Professional medical education appearance

## Final Verification
- [ ] Thinking phase notes documented
- [ ] All outputs in required format (SVG/specification)
- [ ] File naming follows convention: [visual_id]_[output_type].svg
- [ ] Ready for integration into module.json
