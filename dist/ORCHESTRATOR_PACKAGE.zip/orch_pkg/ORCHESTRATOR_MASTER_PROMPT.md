# ORCHESTRATOR MASTER PROMPT
# CORTEX-SHELL — Parallel Visual Generation Agent
# Version: 1.0 | Batch 6 | 2026-06-10
# ── Send this ENTIRE file as your single-turn prompt to the CLI agent ──

---

## IDENTITY & MISSION

You are the **CORTEX-SHELL Visual Generation Orchestrator**. Your mission is to generate 54 medical education visuals (each producing 3 coordinated outputs: infographic + diagram + concept map) for geriatric medicine modules.

**Total deliverables:** 54 visuals × 3 outputs = **162 PNG images**

You have access to all tools: file system, Python execution, sub-agent spawning, API calls.
Execute this mission **in a single turn** using maximum parallel sub-agent invocations.

---

## PACKAGE STRUCTURE (already extracted)

```
ORCHESTRATOR_PACKAGE/
├── ORCHESTRATOR_MASTER_PROMPT.md          ← This file
├── visual_packages_54/                    ← 54 visual packages
│   ├── PACKAGE_SUMMARY.json
│   └── visual_[id]/
│       ├── visual_[id]_ultra_prompt.json  ← Medical context + generation specs
│       ├── visual_[id]_context.json       ← Section context, glossary, references
│       └── visual_[id]_quality_checklist.md
├── semi_finished_output/                  ← Pre-built scaffolding (no images yet)
│   ├── mod_geriatrics_001/
│   │   ├── module.json                   ← Updated with correct src paths
│   │   └── assets/                       ← Images go here
│   └── mod_geriatrics_klinis_001/
│       ├── module.json
│       └── assets/
├── scripts/
│   ├── orchestrate_all.py                ← MAIN ENTRY POINT
│   ├── generate_single_visual.py         ← Per-visual generation (called by orchestrator)
│   ├── update_status.py                  ← Post-generation: marks module.json
│   ├── finalize_manifest.py              ← Post-generation: updates manifest
│   └── validate_completion.py            ← Completion validation
└── config/
    ├── generation_manifest.json          ← 162-task manifest, 6 batches
    ├── generation_config.json            ← API settings, sizes, quality
    └── visual_manifest_updated.json      ← Pre-filled manifest (paths assigned)
```

---

## STEP-BY-STEP EXECUTION

### PHASE 1 — SETUP (do this first, once)

```bash
# 1. Navigate to package root
cd /path/to/ORCHESTRATOR_PACKAGE

# 2. Install dependencies
pip install openai pillow requests

# 3. Set API key
export OPENAI_API_KEY="your-key-here"

# 4. Verify setup
python3 scripts/orchestrate_all.py --dry-run
# Expected: 54 tasks created, 162 placeholder files, no errors
```

**Verify dry-run output:**
- `semi_finished_output/mod_geriatrics_001/assets/` — 72 files (24 visuals × 3)
- `semi_finished_output/mod_geriatrics_klinis_001/assets/` — 90 files (30 visuals × 3)
- `config/GENERATION_LOG.json` — shows 54 complete, 0 failed

---

### PHASE 2 — PARALLEL GENERATION (main work)

**Option A — Full parallel run (recommended):**
```bash
python3 scripts/orchestrate_all.py --api-key $OPENAI_API_KEY --parallel 10
```

**Option B — Batch by batch (safer, easier to monitor):**
```bash
python3 scripts/orchestrate_all.py --batch 1 --parallel 9  # 9 visuals
python3 scripts/orchestrate_all.py --batch 2 --parallel 9
python3 scripts/orchestrate_all.py --batch 3 --parallel 9
python3 scripts/orchestrate_all.py --batch 4 --parallel 9
python3 scripts/orchestrate_all.py --batch 5 --parallel 9
python3 scripts/orchestrate_all.py --batch 6 --parallel 9
```

**Option C — Sub-agent delegation (maximum parallelism):**
Spawn 6 parallel sub-agents, each running one batch:
```
Sub-agent 1: python3 scripts/orchestrate_all.py --batch 1 --parallel 9
Sub-agent 2: python3 scripts/orchestrate_all.py --batch 2 --parallel 9
Sub-agent 3: python3 scripts/orchestrate_all.py --batch 3 --parallel 9
Sub-agent 4: python3 scripts/orchestrate_all.py --batch 4 --parallel 9
Sub-agent 5: python3 scripts/orchestrate_all.py --batch 5 --parallel 9
Sub-agent 6: python3 scripts/orchestrate_all.py --batch 6 --parallel 9
```

**Batch distribution:**
- Batch 1: tasks 01–09 (9 visuals — mod_geriatrics_001 part 1)
- Batch 2: tasks 10–18 (9 visuals — mod_geriatrics_001 part 2)
- Batch 3: tasks 19–24 + 25–27 (mod_geriatrics_001 rest + klinis start)
- Batch 4: tasks 28–36 (9 visuals — mod_geriatrics_klinis_001 part 1)
- Batch 5: tasks 37–45 (9 visuals — mod_geriatrics_klinis_001 part 2)
- Batch 6: tasks 46–54 (9 visuals — mod_geriatrics_klinis_001 final)

---

### PHASE 3 — POST-PROCESSING (run after all images generated)

```bash
# Mark generated visuals in module.json
python3 scripts/update_status.py

# Update visual manifest
python3 scripts/finalize_manifest.py

# Validate completion (generates COMPLETION_REPORT.json)
python3 scripts/validate_completion.py
```

**Expected output:**
```
=== COMPLETION REPORT ===
Total:     54 visuals (162 images)
Complete:  54 (100.0%)
Partial:   0
Missing:   0
```

---

### PHASE 4 — INTEGRATION

Copy generated assets to CORTEX-SHELL repository:

```bash
cp -r semi_finished_output/mod_geriatrics_001/ \
      /path/to/CORTEX-SHELL/app_data/domains/materi/modules/mod_geriatrics_001/

cp -r semi_finished_output/mod_geriatrics_klinis_001/ \
      /path/to/CORTEX-SHELL/app_data/domains/materi/modules/mod_geriatrics_klinis_001/

# Update runtime manifest
cp config/visual_manifest_updated.json \
   /path/to/CORTEX-SHELL/app_data/runtime/visual_asset_manifest.generated.json
```

---

## IMAGE GENERATION SPECIFICATIONS

Each visual produces **3 PNG files:**

### Output 1 — INFOGRAPHIC (`visual_id_infographic.png`)
- **Size:** 1792×1024 (landscape, DALL-E 3 max quality)
- **Content:** Key facts, statistics, icons, color-coded sections
- **Style:** Medical education, grid layout, high contrast
- **Prompt approach:** "Medical education INFOGRAPHIC about: [topic]..."

### Output 2 — REALISTIC DIAGRAM (`visual_id_diagram.png`)
- **Size:** 1024×1024 (square)
- **Content:** Anatomical/physiological structures with labels
- **Style:** Clinical illustration, color-coded, directional arrows
- **Prompt approach:** "Detailed medical DIAGRAM illustrating: [topic]..."

### Output 3 — CONCEPT MAP (`visual_id_concept_map.png`)
- **Size:** 1024×1024 (square)
- **Content:** Hierarchical mind-map, nodes and connections
- **Style:** Clean, nodes with labeled connections, color-coded by category
- **Prompt approach:** "Medical CONCEPT MAP / mind map for: [topic]..."

---

## QUALITY GATES

After generation, verify each image:
```
✓ File exists and >50KB (not a placeholder or error response)
✓ Shows correct medical content (not generic/wrong)
✓ Labels are legible (not blurry or illegible text)
✓ Color scheme is professional medical (not neon/cartoon)
✓ Content matches visual_id topic
```

If any image fails: re-run specific visual:
```bash
python3 scripts/generate_single_visual.py visual_[failed_id] --api-key $KEY
```

---

## ERROR HANDLING

### API Rate Limit
```bash
# Reduce parallel workers
python3 scripts/orchestrate_all.py --parallel 3 --resume
```

### Partial completion
```bash
# Resume from where you left off (skips already-generated)
python3 scripts/orchestrate_all.py --resume --api-key $KEY
```

### Single visual failure
```bash
python3 scripts/generate_single_visual.py visual_geriatric_aging_overview_01 -k $KEY
```

### Full reset
```bash
rm -f semi_finished_output/*/assets/*.png
python3 scripts/orchestrate_all.py --api-key $KEY
```

---

## SUB-AGENT INSTRUCTIONS

If you choose Option C (spawn 6 parallel sub-agents):

**Each sub-agent receives:**
1. This file (`ORCHESTRATOR_MASTER_PROMPT.md`) as context
2. Their specific batch number
3. API key
4. Working directory path

**Each sub-agent's task:**
```
You are a generation sub-agent for CORTEX-SHELL Batch 6.
Your batch: [N]
Package location: /path/to/ORCHESTRATOR_PACKAGE
API key: [KEY]

Execute:
  python3 scripts/orchestrate_all.py --batch [N] --parallel 9 --api-key [KEY]

Report back:
  - Number of visuals completed
  - Number of failures (with visual IDs)
  - Any errors encountered
```

---

## EXPECTED FILE OUTPUT

After successful completion, assets directories will contain:

```
semi_finished_output/mod_geriatrics_001/assets/
├── visual_gerimeds_demographics_01_infographic.png
├── visual_gerimeds_demographics_01_diagram.png
├── visual_gerimeds_demographics_01_concept_map.png
├── visual_gerimeds_body_composition_changes_01_infographic.png
... (72 files total for mod_geriatrics_001)

semi_finished_output/mod_geriatrics_klinis_001/assets/
├── visual_geriatric_aging_overview_01_infographic.png
├── visual_geriatric_aging_overview_01_diagram.png
├── visual_geriatric_aging_overview_01_concept_map.png
... (90 files total for mod_geriatrics_klinis_001)
```

**Total: 162 PNG files**

---

## TIMING ESTIMATES

| Strategy | Workers | Time |
|----------|---------|------|
| Sequential | 1 | ~2.7 hours |
| Moderate parallel | 5 | ~35 min |
| Full parallel | 10 | ~20 min |
| 6 sub-agents × 9 each | 54 | ~8-12 min |

---

## COMPLETION CHECKLIST

```
[ ] Phase 1: dry-run passes (162 placeholder files)
[ ] Phase 2: all 162 real images generated
[ ] Phase 3: update_status.py run — all 54 marked 'generated'
[ ] Phase 3: finalize_manifest.py run — manifest updated
[ ] Phase 3: validate_completion.py — 100% complete
[ ] Phase 4: assets copied to CORTEX-SHELL repo
[ ] Phase 4: visual_manifest_updated.json deployed
[ ] Phase 4: module.json files deployed
[ ] Final: CORTEX-SHELL app shows all visual assets
```

---

*CORTEX-SHELL Batch 6 Visual Generation Orchestrator*
*54 visuals × 3 outputs = 162 medical education images*
