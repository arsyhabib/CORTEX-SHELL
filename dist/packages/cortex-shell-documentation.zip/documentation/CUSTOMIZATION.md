# CORTEX-SHELL Customization Guide

Panduan lengkap untuk mengkustomisasi CORTEX-SHELL template untuk aplikasi Anda.

## 1️⃣ Quick Customization (5 menit)

### Ubah Nama & Identitas Aplikasi

Edit `index.html`:

```html
<!-- Line 7 -->
<title>YOUR APP NAME</title>

<!-- Line 13 -->
<meta name='theme-color' content='#111327'>
<!-- Change to your brand color -->

<!-- Line 16 -->
<meta name='apple-mobile-web-app-title' content='YOUR APP NAME'>

<!-- Line 18 -->
<meta name='application-name' content='YOUR APP NAME'>

<!-- Search for "CORTEX Studio" and replace with your app name -->
```

### Ubah Warna & Theme

Cari `body {` CSS rule:

```css
body {
  background: var(--cortex-theme-bg, #060818);  /* Change default */
  --cortex-primary: #8b5cf6;  /* Change primary color */
}
```

### Ubah Boot Loader Messages

Cari `msgs` array di boot loader script (line ~4756):

```js
var msgs = [
  'Starting application...',
  'Loading modules...',
  'Preparing interface...',
  // Add your custom messages
];
```

## 2️⃣ Moderate Customization (30 menit)

### Ubah Home Page Content

Dalam `cortex-app.js`, find `HomeNeural` function, modify:
- Heading text
- Description text
- Featured cards
- Quick action buttons

### Add Custom Pages

In `cortex-app.js`:

```js
// 1. Create component
function MyCustomPage() {
  return React.createElement('div', { className: 'page' },
    React.createElement('h1', null, 'My Custom Content')
  );
}

// 2. Add to exports
Object.assign(window, { MyCustomPage, ... });

// 3. Add to page routing
const CORTEX_LIBRARY_PAGES = [
  { id: 0, label: 'Home', ... },
  { id: 1, label: 'My Custom', icon: '✨', component: MyCustomPage },
  // ...
];

// 4. Update router to handle new page
if (page === 1) return React.createElement(MyCustomPage, {...});
```

### Create Custom Theme

In `cortex-app.js`, find `THEMES` object, add:

```js
const THEMES = {
  myTheme: {
    id: 'myTheme',
    name: 'My Brand',
    emoji: '🎨',
    colors: {
      // Copy from another theme and modify
      primary: '#YOUR_COLOR',
      secondary: '#YOUR_COLOR',
      // ... all 20+ colors
    },
    glass: {
      blur: 12,
      saturation: 120,
      opacity: 0.4
    },
    borderRadius: 20,
    fontWeight: 600
  },
  // ... other themes
};

// Add to theme order
const CORTEX_THEME_ORDER = ['myTheme', 'neural', 'aurora', ...];
```

## 3️⃣ Advanced Customization (2+ hours)

### Modify Core Component Tree

Edit `CortexLibraryShell` component:
- Change layout structure
- Modify sidebar navigation
- Add new navigation items
- Change FAB behavior

Example:
```js
function CortexLibraryShell() {
  const [page, setPage] = React.useState(0);
  const theme = useTheme();
  
  return React.createElement('div', { className: 'shell' },
    // LEFT: Custom sidebar
    React.createElement('div', { className: 'sidebar' },
      // Your navigation here
    ),
    
    // MAIN: Page content
    React.createElement('div', { className: 'main-content' },
      // Render page based on state
    ),
    
    // BOTTOM: Custom FAB
    React.createElement('div', { className: 'fab' },
      // Your action buttons
    )
  );
}
```

### Integrate External Data

Add fetch logic in useEffect:

```js
React.useEffect(() => {
  fetch('./app_data/content.json')
    .then(r => r.json())
    .then(data => setContent(data))
    .catch(err => console.error('Load failed:', err));
}, []);
```

### Add Third-Party Libraries

Option 1 - Add to vendor-libs:
```bash
# Download minified library
cp node_modules/library/dist/library.min.js assets/vendor/

# Add <script> tag before cortex-app.js in index.html
<script src="./assets/vendor/library.min.js"></script>

# Use in cortex-app.js
const lib = window.YourLibraryName;
```

Option 2 - Inline in cortex-app.js:
```js
// Paste minified code at bottom of cortex-app.js
// Use directly
```

### Custom Authentication

Add auth check in boot:

```js
// Add after cortex-app.js loads
<script>
  window.addEventListener('load', function() {
    // Check if user authenticated
    if (!isAuthenticated()) {
      // Show login modal or redirect
      window.location.href = '/login';
    }
  });
</script>
```

### Service Worker Customization

Modify `sw.js` for different caching strategies:

```js
// Cache HTML pages with different strategy
if (url.pathname.endsWith('.html')) {
  // Cache-first: serve cached first
  event.respondWith((async () => {
    const cached = await caches.match(event.request);
    if (cached) return cached;
    return fetch(event.request);
  })());
}

// API calls: network-first
if (url.pathname.includes('/api/')) {
  // Fetch first, fallback to cache
  event.respondWith((async () => {
    try {
      return await fetch(event.request);
    } catch {
      return await caches.match(event.request);
    }
  })());
}
```

## 4️⃣ AI Agent Integration

### Provide Schemas to AI

When asking AI to generate content:

```
I'm using CORTEX-SHELL template for my new app.
Here are the schemas for content generation:

CONTENT_SCHEMA_MASTER - defines all content types and structure
DOMAIN_SCHEMA_DESIGN - defines data models and relationships
PROMPT_MATERI_REFINED - template for generating educational content
PROMPT_SOAL_REFINED - template for generating quiz/assessment

Please generate content module that follows these schemas exactly.
Target output: JSON matching CONTENT_SCHEMA_MASTER structure.

My app uses:
- React 18 for rendering
- 6 themes with glass morphism
- Service worker for offline
- Local JSON-based content
```

### Custom Schema for AI

Create your own schema file:

```markdown
# My App Content Schema

## Content Module Structure
{
  "module": {
    "id": "string",
    "appId": "my-app-id",
    "type": "learning|tutorial|interactive",
    "metadata": {
      "difficulty": "beginner|intermediate|advanced",
      "duration": "number (minutes)",
      "category": "string"
    },
    "content": {
      "title": "string",
      "description": "string",
      "blocks": [...]
    }
  }
}

## Content Block Types

### text_block
Type for paragraphs, descriptions
```

## 🎯 Common Customization Recipes

### Recipe 1: Dark Mode Only
```js
// Remove all themes except 'monochrome'
const CORTEX_THEME_ORDER = ['monochrome'];

// Force monochrome theme on start
const [themeId, setThemeId] = React.useState('monochrome');
```

### Recipe 2: Different Home Pages Per User Role

```js
function HomeRouter() {
  const userRole = getCurrentUserRole();
  
  switch(userRole) {
    case 'admin': return React.createElement(AdminHome);
    case 'student': return React.createElement(StudentHome);
    case 'teacher': return React.createElement(TeacherHome);
    default: return React.createElement(HomeNeural);
  }
}
```

### Recipe 3: Multi-Language Support

```js
const TRANSLATIONS = {
  en: { home: 'Home', settings: 'Settings', ... },
  id: { home: 'Beranda', settings: 'Pengaturan', ... },
  es: { home: 'Inicio', settings: 'Configuración', ... }
};

const [lang, setLang] = React.useState('en');
const t = (key) => TRANSLATIONS[lang][key];

// Use: <h1>{t('home')}</h1>
```

### Recipe 4: Enable Offline-First Content

```js
// Pre-cache all JSON content in SW
const CORE_ASSETS = [
  './app_data/content.json',
  './app_data/config.json',
  // ... all JSON files
];

// App uses cached version if offline
fetch(url)
  .then(r => r.json())
  .catch(err => {
    // Load from localStorage fallback
    return JSON.parse(localStorage.getItem(url));
  });
```

## ✅ Customization Checklist

- [ ] Change app title and theme color
- [ ] Update boot loader messages
- [ ] Customize home page content
- [ ] Add custom pages (if needed)
- [ ] Create custom theme (if needed)
- [ ] Update favicon and PWA icons
- [ ] Test all 6 themes
- [ ] Test responsive on mobile
- [ ] Update service worker cache name
- [ ] Test offline mode (DevTools → offline)
- [ ] Test on target browsers/devices
- [ ] Deploy to server/GitHub Pages

---

**Next Steps:**
1. Start with Quick Customization
2. Test thoroughly
3. Deploy to test server
4. Gather feedback
5. Iterate with Moderate Customization
6. Polish and go live

See SETUP_GUIDE.md for deployment instructions.
