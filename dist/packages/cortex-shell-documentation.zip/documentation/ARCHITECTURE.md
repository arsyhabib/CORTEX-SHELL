# CORTEX-SHELL Architecture Overview

## 🏗️ Application Structure

CORTEX-SHELL adalah single-page React application yang di-deploy sebagai static files dengan service worker offline support.

### Core Architecture

```
index.html (131KB minified)
    ↓
    ├─ Load vendor libraries
    │  ├─ assets/vendor/react.min.js (11KB)
    │  ├─ assets/vendor/react-dom.min.js (129KB)
    │  └─ assets/vendor/marked.min.js (36KB)
    │
    ├─ Load pre-compiled app
    │  └─ cortex-app.js (426KB vanilla JS)
    │
    └─ Render React tree
       └─ <CortexLibraryShell> → entire app
```

### Key Design Decisions

1. **Pre-Compiled JSX** (not Babel Standalone)
   - Eliminates 3.5MB Babel CDN
   - Build-time compilation (not runtime)
   - Production-ready JavaScript

2. **Local Vendor Libraries** (not CDN)
   - React/ReactDOM from npm (UMD builds)
   - Marked from npm
   - Works offline, faster load

3. **Single-File Deploy**
   - index.html + cortex-app.js + vendor files = complete app
   - No build server needed
   - Copy files → deploy anywhere

4. **Service Worker**
   - Offline-first caching strategy
   - Network-first for HTML (stay fresh)
   - Stale-while-revalidate for assets
   - Auto-cache on first visit

## 📐 Component Hierarchy

```
CortexErrorBoundary (catches all errors)
  ↓
CortexLibraryShell (main app shell)
  ├─ ThemeProvider (6 themes: neural, aurora, gold, neon, bloom, monochrome)
  ├─ PageSidebar (navigation)
  ├─ Main Content Router
  │  ├─ Home page (HomeNeural, HomeAurora, etc by theme)
  │  ├─ Learning page (courses, learning paths)
  │  ├─ Settings page
  │  ├─ AI Workspace (chat, prompts)
  │  ├─ 3D Media Viewer
  │  ├─ Quiz/Assessment
  │  └─ [Custom Pages - add here]
  │
  └─ FAB (Floating Action Button)
     ├─ AI Workspace toggle
     ├─ Quick actions
     └─ Dock items

```

## 🎨 Design System

### Glass Morphism
All components use glass effect:
```js
glassStyle() = {
  backdropFilter: `blur(${glass.blur}px) saturate(${glass.saturation}%)`,
  background: `rgba(...)`, // theme colors
  border: `1px solid ${colors.glassBorder}`,
  borderRadius: theme.borderRadius
}
```

### 6 Themes
Each theme has:
- `colors` - 20+ color tokens
- `glass` - blur, saturation, opacity
- `borderRadius` - consistent rounding
- `fontWeight` - text hierarchy

Theme switching: `useTheme()` hook → entire app re-renders with new theme

### Responsive Design
Mobile-first breakpoints:
- `<600px` - Mobile
- `600-1024px` - Tablet
- `>1024px` - Desktop

## 💾 Data Layer

### Runtime Assets
```
app_data/
  ├─ runtime/
  │  ├─ content_index.json      # All content modules
  │  └─ visual_asset_manifest.json # All visual packages
  ├─ system/
  │  ├─ config/
  │  │  └─ app_config.json
  │  └─ identity/
  │     └─ app_identity.json
  └─ [domain-data]/
     ├─ modules/
     ├─ assets/
     └─ config/
```

### Content Schema
Content is JSON-based following CONTENT_SCHEMA_MASTER:
```json
{
  "module": {
    "id": "mod_domain_001",
    "type": "learning|quiz|interactive",
    "domain": "anatomy|physiology|pathology",
    "content": {
      "title": "...",
      "description": "...",
      "blocks": [
        {
          "type": "text|image|video|3d|interactive",
          "data": {...}
        }
      ]
    }
  }
}
```

## 🔄 State Management

CORTEX uses React's built-in state:
- `useState` for component state
- `useContext` for theme, config
- `useRef` for refs
- `useEffect` for side effects
- Props drilling for simplicity

No Redux needed for current scope.

## 📡 API Integration

### Fetch Pattern
```js
fetch(url)
  .then(r => r.json())
  .catch(err => {
    // Show error UI
    // Fallback to cached data if available
  })
```

### Service Worker Caching
- Network-first: HTML (stay fresh)
- Stale-while-revalidate: assets (fast load)
- Cache hits: serve immediately
- Cache misses: fetch + cache for next time

## 🚀 Performance

### Bundle Sizes
- index.html: 131KB (styles + HTML)
- cortex-app.js: 426KB (pre-compiled React + components)
- vendors: 176KB (React, ReactDOM, Marked)
- **Total: ~733KB** (vs 3.5MB+ with Babel CDN)

### Load Performance
1. **index.html** loaded (1-2ms)
2. **vendor scripts** parsed (100-150ms)
3. **cortex-app.js** parsed (200-300ms)
4. **React renders** entire tree (100-200ms)
5. **Service worker** registers (async)
6. **Total to interactive:** ~500-700ms on 3G

### Caching
- Vendor libs: cached 1 year (immutable)
- cortex-app.js: no-cache (revalidate on each load)
- index.html: no-cache (always fetch fresh)
- Other assets: stale-while-revalidate (cache 30 days)

## 🔐 Security

### Content Security Policy
Current state: permissive (dev-friendly)
For production, add:
```html
<meta http-equiv="Content-Security-Policy" 
  content="default-src 'self'; script-src 'self' 'wasm-unsafe-eval'; style-src 'self' 'unsafe-inline'">
```

### XSS Prevention
- React auto-escapes content
- Use `dangerouslySetInnerHTML` only for trusted markdown
- Markdown: use `marked` with safe options

### CORS
- Service worker handles CORS for offline
- Same-origin by default
- No credentials sent

## 📊 Monitoring & Debugging

### Browser DevTools
1. **Console** - check for errors
2. **Network** - check asset loads
3. **Application** - check service worker + cache
4. **Performance** - measure load times

### Error Boundaries
`<CortexErrorBoundary>` catches component errors:
- Prevents white screen
- Shows error message
- Allows recovery

### Offline Detection
```js
navigator.onLine ? // online : // offline
window.addEventListener('online', handler)
window.addEventListener('offline', handler)
```

## 🔧 Extending the App

### Add New Page/Route
1. Create component in cortex-app.js
2. Add to `CORTEX_LIBRARY_PAGES` array
3. Handle in router logic
4. Use `useTheme()` for styling

### Add New Theme
1. Add theme config to `THEMES` object
2. Define all color tokens
3. Test contrast on all pages
4. Add to `CORTEX_THEME_ORDER`

### Add New Component Library
1. Create component in cortex-app.js
2. Export via `Object.assign(window, {...})`
3. Use same glass morphism patterns
4. Test responsive behavior

## 🌐 Deployment Targets

### GitHub Pages (free)
- Push to `gh-pages` branch
- Auto-deploys from root
- Add `.nojekyll` to disable Jekyll
- Works with service worker

### Netlify
- Connect GitHub repo
- Build command: (none - static)
- Publish directory: `.`
- Auto-redirects 404.html for SPA

### Vercel
- Import GitHub repo
- Framework: None (static)
- Deploy automatically

### Self-Hosted
- Copy files to any web server
- Serve with HTTPS
- Set cache headers appropriately
- Service worker will cache rest

---

**For detailed implementation guides, see documentation/ folder**
