# AI Agent Guide - CORTEX-SHELL Content Generation

Panduan untuk AI agents dalam membuat konten, modul, dan data yang sesuai dengan CORTEX-SHELL template.

## 🤖 Overview

CORTEX-SHELL menggunakan JSON-based content architecture dengan definitive schemas. AI agents dapat menggunakan schemas ini untuk menghasilkan konten yang 100% compatible dengan aplikasi.

## 📋 Core Schemas

### 1. CONTENT_SCHEMA_MASTER
**Tujuan:** Mendefinisikan semua content types dan struktur umum

**Gunakan ketika:**
- Membuat modul pembelajaran baru
- Membuat quiz/assessment
- Membuat interactive content
- Merancang course structure

**Key Sections:**
- Module definition (id, type, metadata)
- Content blocks (text, image, video, 3D, interactive)
- Block validation rules
- Example modules

### 2. DOMAIN_SCHEMA_DESIGN
**Tujuan:** Mendefinisikan data model dan relationships untuk domain tertentu

**Gunakan ketika:**
- Membuat konten untuk domain baru (anatomy, surgery, etc)
- Menentukan learning progression
- Merancang prerequisite relationships
- Membuat assessment rubrics

**Key Sections:**
- Domain hierarchy (subjects → topics → subtopics)
- Learning objectives (taxonomy levels)
- Assessment criteria
- Knowledge graph structure

### 3. DOMAIN_CONTENT_GUIDE
**Tujuan:** Best practices untuk membuat konten yang efektif

**Gunakan ketika:**
- Menentukan tone dan style
- Memilih tipe content block
- Mengatur difficulty progression
- Memilih media types

### 4. PROMPT_MATERI_REFINED
**Tujuan:** Template refinement untuk materi/konten edukatif

**Gunakan ketika:**
- Menulis deskripsi konten
- Membuat educational content
- Menentukan learning approach
- Memilih pedagogical techniques

### 5. PROMPT_SOAL_REFINED
**Tujuan:** Template untuk membuat soal/quiz berkualitas

**Gunakan ketika:**
- Membuat assessment items
- Membuat multiple choice questions
- Membuat scenario-based questions
- Menentukan difficulty level

### 6. RESOURCE_ARCHITECTURE
**Tujuan:** Memahami asset management dan struktur file

**Gunakan ketika:**
- Merencana visual assets
- Mengorganisir 3D models
- Mengatur video/media library
- Membuat asset manifest

## ✅ Workflow untuk Generate Konten

### Step 1: Pahami Struktur Target
```
Baca: CONTENT_SCHEMA_MASTER.md → pahami module dan block structure
Baca: DOMAIN_SCHEMA_DESIGN.md → pahami domain hierarchy
Tentukan: jenis content apa yang akan dibuat (learning/quiz/interactive)
```

### Step 2: Plan Content
```
Baca: DOMAIN_CONTENT_GUIDE.md → tentukan approach dan style
Baca: PROMPT_MATERI_REFINED.md (jika konten) → pahami template
Baca: PROMPT_SOAL_REFINED.md (jika quiz) → pahami template
Sketsa: learning objectives, assessment criteria
```

### Step 3: Generate Content
```
Ikuti struktur dari CONTENT_SCHEMA_MASTER
Output: JSON yang valid sesuai schema
Validate: pastikan semua required fields ada
Format: properly formatted JSON (2-space indentation)
```

### Step 4: Validate Output
```
Check: apakah module mengikuti schema structure?
Check: apakah semua block types valid?
Check: apakah IDs unique dan well-formatted?
Check: apakah metadata lengkap?
```

## 📝 Content Generation Examples

### Example 1: Membuat Learning Module

**Input dari user:**
```
"Buatkan learning module tentang anatomical planes dalam bahasa Indonesia.
Domain: Anatomy Fundamentals
Level: Beginner
Estimasi durasi: 15 menit"
```

**AI Agent Process:**

1. Read CONTENT_SCHEMA_MASTER → understand module structure
2. Read DOMAIN_SCHEMA_DESIGN → find where "anatomical-planes" fits
3. Read DOMAIN_CONTENT_GUIDE → decide content blocks
4. Read PROMPT_MATERI_REFINED → follow template
5. Generate JSON:

```json
{
  "module": {
    "id": "mod_anatomy_anatomical_planes_001",
    "appId": "cortex-medical-learning",
    "type": "learning",
    "domain": "anatomy",
    "metadata": {
      "title": "Anatomical Planes",
      "description": "Understanding fundamental anatomical planes and directional terms",
      "difficulty": "beginner",
      "duration": 15,
      "category": "Anatomy Fundamentals",
      "language": "en",
      "version": "1.0.0",
      "tags": ["anatomy", "fundamentals", "spatial-orientation"]
    },
    "learning_objectives": [
      "Define sagittal, frontal, and transverse planes",
      "Identify anatomical planes on medical imaging",
      "Use directional terminology correctly",
      "Apply planes to clinical scenarios"
    ],
    "content": {
      "intro": {
        "summary": "Brief introduction to anatomical planes and terminology",
        "estimated_time": 2
      },
      "blocks": [
        {
          "id": "block_001",
          "type": "text",
          "order": 1,
          "title": "Introduction to Anatomical Planes",
          "content": "Anatomical planes are imaginary lines used to describe the position and movement of body structures...",
          "estimated_time": 3
        },
        {
          "id": "block_002",
          "type": "image",
          "order": 2,
          "title": "Three Main Planes",
          "description": "Visual representation of sagittal, frontal, and transverse planes",
          "source": "assets/anatomy/planes_illustration.svg",
          "alt_text": "Anatomical planes diagram",
          "estimated_time": 2
        },
        {
          "id": "block_003",
          "type": "text",
          "order": 3,
          "title": "Directional Terminology",
          "content": "Superior (above), Inferior (below), Anterior (front), Posterior (back)...",
          "estimated_time": 4
        },
        {
          "id": "block_004",
          "type": "interactive",
          "order": 4,
          "title": "Interactive Plane Identification",
          "description": "Identify planes on 3D anatomy model",
          "data": {
            "model_id": "human_anatomical_model_001",
            "interactive_type": "labeled_regions",
            "learnable_elements": ["sagittal_plane", "frontal_plane", "transverse_plane"]
          },
          "estimated_time": 4
        }
      ]
    },
    "assessment": {
      "type": "formative",
      "items": [
        {
          "id": "q_001",
          "type": "multiple_choice",
          "question": "Which plane divides the body into left and right halves?",
          "options": [
            { "text": "Sagittal plane", "correct": true },
            { "text": "Frontal plane", "correct": false },
            { "text": "Transverse plane", "correct": false }
          ],
          "explanation": "The sagittal plane runs vertically and divides the body into left and right portions"
        }
      ]
    }
  }
}
```

### Example 2: Membuat Quiz Module

**Input dari user:**
```
"Buatkan 5 soal quiz tentang anatomical planes.
Difficulty: intermediate
Focus on clinical application"
```

**Output JSON:**

```json
{
  "module": {
    "id": "quiz_anatomy_planes_intermediate_001",
    "type": "quiz",
    "domain": "anatomy",
    "metadata": {
      "title": "Anatomical Planes - Clinical Application Quiz",
      "difficulty": "intermediate",
      "duration": 10,
      "passing_score": 70
    },
    "content": {
      "items": [
        {
          "id": "q_001",
          "type": "multiple_choice",
          "difficulty": "intermediate",
          "question": "A CT scan shows a tumor in the transverse plane at the level of L4. Which of the following best describes this?",
          "options": [
            { "text": "The tumor divides the body left and right", "correct": false },
            { "text": "The tumor is at the level of the lumbar spine, L4", "correct": true },
            { "text": "The tumor is anterior to the spine", "correct": false }
          ],
          "explanation": "Transverse planes show horizontal cross-sections. L4 is a specific vertebral level."
        },
        {
          "id": "q_002",
          "type": "scenario",
          "difficulty": "intermediate",
          "scenario": "A radiologist describes a fracture 'lateral to the midline on the sagittal view.' What does this mean?",
          "question": "Based on this description, where is the fracture located?",
          "options": [
            { "text": "On the left side of the midline", "correct": true },
            { "text": "On the right side of the midline", "correct": true },
            { "text": "In the anterior view", "correct": false },
            { "text": "Cannot be determined from this description", "correct": false }
          ],
          "explanation": "Lateral means away from midline (could be left or right), and sagittal view is from side"
        }
      ]
    }
  }
}
```

## 🎯 Best Practices untuk AI Generation

### ✅ DO

1. **Follow Schema Structure Exactly**
   - Gunakan semua required fields
   - Respect field types dan formats
   - Validate sebelum output

2. **Use Realistic IDs**
   - Format: `mod_[domain]_[topic]_[sequence]`
   - Contoh: `mod_anatomy_cardiovascular_001`
   - Make IDs globally unique

3. **Write Clear Learning Objectives**
   - Use Bloom's taxonomy (remember → evaluate)
   - Make them measurable
   - Align dengan content

4. **Create Engaging Content**
   - Vary block types (text, image, video, interactive)
   - Break into digestible chunks
   - Include summaries

5. **Provide Rich Metadata**
   - Duration estimates
   - Difficulty levels
   - Prerequisites
   - Tags for searchability

### ❌ DON'T

1. **Don't Mix JSON Structure**
   ```
   ❌ BAD: 
   {
     "module": "string value"  // Wrong: should be object
   }
   
   ✅ GOOD:
   {
     "module": { "id": "...", "content": {...} }
   }
   ```

2. **Don't Use Placeholder Content**
   ```
   ❌ BAD: "content": "Lorem ipsum dolor sit amet..."
   
   ✅ GOOD: "content": "Detailed explanation of concept..."
   ```

3. **Don't Forget Block IDs**
   ```
   ❌ BAD:
   "blocks": [
     { "type": "text", "title": "..." }  // Missing id
   ]
   
   ✅ GOOD:
   "blocks": [
     { "id": "block_001", "type": "text", "title": "..." }
   ]
   ```

4. **Don't Create Invalid References**
   ```
   ❌ BAD: "source": "assets/images/not_available.png"
   
   ✅ GOOD: Reference only assets that actually exist
   ```

## 🔄 Iterative Improvement Process

1. **First Generation**
   - Generate basic content following schema
   - Focus on correctness and structure

2. **Refinement**
   - Add richer content
   - Improve explanations
   - Add more assessment items

3. **Enhancement**
   - Add interactive elements
   - Include visual assets
   - Add clinical scenarios

4. **Validation**
   - Check against schema
   - Verify all IDs unique
   - Test in application

## 📊 Content Quality Metrics

When generating content, AI should aim for:

- **Accuracy:** 100% factually correct
- **Clarity:** Understandable to target audience
- **Completeness:** All required fields present
- **Relevance:** Aligned with learning objectives
- **Engagement:** Multiple content types, interactive
- **Accessibility:** Clear language, descriptions
- **Consistency:** Formatting matches schema

## 🚀 Advanced: Custom Schema Creation

Users can provide custom schemas:

```markdown
# My Custom Schema

Provide this to AI Agent:

## Content Module Structure
{
  "module": {
    "id": "custom_id",
    "type": "my_custom_type",
    "customField1": "...",
    "customField2": "..."
  }
}

## Validation Rules
- id must be unique
- customField1 must be non-empty
- etc.
```

## 📞 Troubleshooting

**Q: AI generates invalid JSON**
A: Validate JSON syntax before using. Use: `JSON.parse()` test

**Q: Content doesn't appear in app**
A: Check:
1. Module ID matches expected pattern
2. All required fields present
3. Block IDs are unique
4. Content file placed correctly

**Q: Fields are optional in schema?**
A: Check CONTENT_SCHEMA_MASTER "required fields" section

---

**Version:** 2.0  
**Last Updated:** June 2026

For schema details, see respective `.md` files in schemas/ folder.
