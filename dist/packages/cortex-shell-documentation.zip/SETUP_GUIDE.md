# CORTEX-SHELL Reusable Package - Setup Guide

Panduan setup untuk membuat aplikasi baru menggunakan CORTEX-SHELL template yang dapat dikustomisasi.

## 📦 Isi Package

```
cortex-shell-reusable/
├── templates/                 # Core app files (ready to use)
│   ├── index.html            # Main HTML template (single-file)
│   ├── cortex-app.js         # Pre-compiled React app (production)
│   ├── sw.js                 # Service worker (offline support)
│   ├── manifest.webmanifest  # PWA manifest
│   ├── 404.html              # Error page
│   └── .nojekyll             # GitHub Pages config
├── vendor-libs/              # CDN libraries (local copies)
│   └── assets/vendor/        # React, ReactDOM, Marked minified
├── schemas/                  # AI-readable schemas for content generation
│   ├── CONTENT_SCHEMA_MASTER.md
│   ├── DOMAIN_SCHEMA_DESIGN.md
│   ├── DOMAIN_CONTENT_GUIDE.md
│   ├── RESOURCE_ARCHITECTURE.md
│   ├── PROMPT_MATERI_REFINED.md
│   └── PROMPT_SOAL_REFINED.md
├── config/                   # Configuration templates
│   └── app_config.template.json
├── documentation/            # How-to guides
│   ├── ARCHITECTURE.md
│   ├── CUSTOMIZATION.md
│   └── AI_AGENT_GUIDE.md
└── scripts/                  # Helper scripts
    └── setup.sh
```

## 🚀 Cara Menggunakan

### Step 1: Persiapan File Lokal
```bash
# Copy ke working directory Anda
cp -r cortex-shell-reusable/templates/* your-app/
cp -r cortex-shell-reusable/vendor-libs/* your-app/

# Optional: copy schemas untuk reference
cp -r cortex-shell-reusable/schemas your-app/docs/schemas
```

### Step 2: Customize index.html
Edit `your-app/index.html`:
- Ubah `<title>` dengan nama aplikasi Anda
- Ubah meta description, theme-color, app name
- Customize CSS variables (warna, fonts, spacing)
- Customize boot loader message

### Step 3: Ubah cortex-app.js (jika diperlukan)
Jika ingin memodifikasi JSX:
1. Extract JSX dari index.html jika ada
2. Install `@babel/core` dan `@babel/preset-react`
3. Compile dengan Babel:
```bash
node -e "
const babel = require('@babel/core');
const fs = require('fs');
const result = babel.transformFileSync('app.jsx', {
  presets: ['@babel/preset-react']
});
fs.writeFileSync('cortex-app.js', result.code);
"
```

### Step 4: Konfigurasi (Optional)
Buat `app_data/system/config/app_config.json`:
```json
{
  "appName": "Your App Name",
  "appVersion": "1.0.0",
  "theme": "neural",
  "defaultLanguage": "id",
  "features": {
    "offline": true,
    "pwa": true,
    "analytics": false
  }
}
```

### Step 5: Deploy ke GitHub Pages (atau server lain)
```bash
# GitHub Pages - push to gh-pages branch
git push origin main:gh-pages

# atau gunakan service worker untuk offline mode
# Service worker auto-cache assets saat first visit
```

## 🎨 Struktur untuk AI Agent

Schemas disediakan agar AI agent dapat:
1. **CONTENT_SCHEMA_MASTER** - Memahami struktur konten yang diharapkan
2. **DOMAIN_SCHEMA_DESIGN** - Mengerti arsitektur domain dan data relationships
3. **PROMPT_MATERI_REFINED** - Template untuk generate materi/konten
4. **PROMPT_SOAL_REFINED** - Template untuk generate soal/quiz

Berikan schemas ini kepada AI agent saat:
- Meminta membuat konten baru
- Membuat modul pembelajaran
- Membuat quiz atau assessment
- Modifying struktur data

## 📝 Customization Points

### CSS Variables (dalam `<style>`)
```css
--cortex-theme-bg: #060818;           /* Background color */
--cortex-primary: #8b5cf6;            /* Primary color */
--cortex-glass: rgba(255,255,255,0.1);/* Glass effect */
```

### Fonts
Edit `@import url(...)` di `<head>` untuk fonts berbeda

### Themes
Modify `THEMES` object dalam cortex-app.js atau create custom themes

### Boot Loader Messages
Edit array `msgs` dalam boot loader script untuk loading messages custom

## 🔧 Troubleshooting

### Black Screen pada Load
- Buka DevTools (F12), cek Console untuk errors
- Hard reload: `Ctrl+Shift+R` (clear cache)
- Check apakah `cortex-app.js` dan vendor files loaded

### Service Worker Issues
- Clear old caches: delete cache storage dari DevTools
- Unregister SW: `navigator.serviceWorker.getRegistrations().then(r => r.map(r => r.unregister()))`
- Update `CACHE_NAME` di `sw.js` untuk force clear

### React/ReactDOM Not Defined
- Pastikan `assets/vendor/react.min.js` dan `react-dom.min.js` di-load sebelum `cortex-app.js`
- Check file paths relatif ke index.html

## 📦 Production Deployment

### Optimizations
1. Minify cortex-app.js (sudah production build)
2. Gzip assets
3. Set cache headers untuk assets/vendor (1 year)
4. Set cache headers untuk index.html (no-cache)

### Headers (untuk GitHub Pages, buat `_headers` atau `.htaccess`)
```
/assets/vendor/*
  Cache-Control: public, max-age=31536000, immutable

/index.html
  Cache-Control: no-cache, must-revalidate

/cortex-app.js
  Cache-Control: no-cache, must-revalidate
```

## 🤖 Menggunakan dengan AI Agent

Saat membuat konten baru:
```
"Buatkan konten baru untuk aplikasi CORTEX-based kami.
Referensi schemas:
- CONTENT_SCHEMA_MASTER.md (untuk struktur konten)
- DOMAIN_SCHEMA_DESIGN.md (untuk data model)
- PROMPT_MATERI_REFINED.md (untuk format materi)

Aplikasi menggunakan:
- React 18 untuk UI
- Service Worker untuk offline
- Glass morphism design system
- 6 themes (neural, aurora, gold, neon, bloom, monochrome)

Target output: JSON modules yang sesuai dengan schema."
```

## 📞 Support

Untuk bantuan atau questions:
- Review documentation di folder `documentation/`
- Check schema examples
- Test dengan browser DevTools

---

**Version:** 2.0-reusable  
**Last Updated:** June 2026  
**License:** ISC
