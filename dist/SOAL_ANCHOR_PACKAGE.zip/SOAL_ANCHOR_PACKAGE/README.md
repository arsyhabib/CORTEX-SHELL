# SOAL ANCHOR PACKAGE — CORTEX-SHELL
## Systematic Work Guide for AI Agents (Exam Set Generation)
### Version: 1.0 | Date: 2026-06-10

---

## WHAT IS THIS PACKAGE?

This package contains EVERYTHING an AI agent needs to correctly process raw exam PDFs
(authentic university exam sets) and generate production-ready `exam_set.json` files
for the CORTEX-SHELL medical education platform.

Send this entire package alongside your raw exam PDF files to the content agent.

---

## FILE STRUCTURE

```
SOAL_ANCHOR_PACKAGE/
├── README.md                           ← You are here. Read this first.
├── CONTENT_SCHEMA_MASTER.md            ← MASTER schema reference (all fields, all rules)
│
├── packages_soal/
│   ├── PROMPT_SOAL_VISION_AGENT.md     ← Main prompt to paste into the agent
│   ├── SCHEMA_EXAM_JSON_REFERENCE.md   ← Detailed exam_set.json field documentation
│   ├── OCR_VISION_PROTOCOL.md          ← Mandatory per-page OCR + Vision protocol
│   ├── BATCH_PROCESSING_GUIDE.md       ← 3-set max batching, master question bank schema
│   └── OUTPUT_VALIDATION_CHECKLIST.md  ← 10-section QA gate before submitting output
│
├── packages_shared/
│   ├── CONTENT_INDEX_REGISTRY_GUIDE.md ← How to add exam set to content_index.kimi.json
│   ├── VISUAL_ASSET_MANIFEST_GUIDE.md  ← Visual asset handling for exam diagrams
│   ├── COMPILE_AUDIT_GUIDE.md          ← Multi-batch compilation and audit report
│   └── APP_INTEGRATION_CHECKLIST.md    ← Final integration gate
│
├── example_exam_sets/
│   ├── exam_asli_01.json               ← GROUND TRUTH: Example authentic exam set
│   └── exam_ai_01.json                 ← GROUND TRUTH: Example AI-generated question bank
│
└── runtime_data/
    └── content_index.kimi.json         ← Current live content registry
```

---

## HOW TO USE THIS PACKAGE

### Step 1 — Read the master schema
Open `CONTENT_SCHEMA_MASTER.md` → Part B (SOAL domain). Understand every field and rule.

### Step 2 — Study the ground truth examples
Open both files in `example_exam_sets/`. Note the structure, field names, and content quality.
- `exam_asli_01.json` — Template for authentic exam extraction
- `exam_ai_01.json` — Template for AI-generated question banks

### Step 3 — Copy the agent prompt
Open `packages_soal/PROMPT_SOAL_VISION_AGENT.md`. Copy the full prompt.
Paste as system prompt or first message to your content agent.

### Step 4 — Send PDFs with protocol
Also share `packages_soal/OCR_VISION_PROTOCOL.md` with the agent.
Exam PDFs often have diagrams, ECGs, imaging, or tables — Vision is mandatory.

### Step 5 — Validate output
After the agent generates exam_set.json, run through `packages_soal/OUTPUT_VALIDATION_CHECKLIST.md`.
Then follow `packages_shared/CONTENT_INDEX_REGISTRY_GUIDE.md` to register the new set.

---

## CRITICAL RULES (SUMMARY)

1. **Max 3 exam sets per batch** — Split larger collections into separate batches
2. **Type C PDFs (pure image/scanned)** — Always use Vision for all pages
3. **answer_index is 0-based** — 0=A, 1=B, 2=C, 3=D. NEVER use letters as index.
4. **Exactly 4 options per question** — No exceptions
5. **explanation required** — Every question needs 3–6 sentences of explanation
6. **type field** — Only `"asli"` or `"ai_generated"` — no other values accepted
7. **Register output** — Always update `content_index.kimi.json` after generating

---

## TWO TYPES OF EXAM SETS

### Type 1: Exam Asli (Authentic)
- Source: Real university exam PDF scans
- `type`: `"asli"`
- `exam_id`: `set_asli_NN`
- All questions: `confidence: "definite"`
- Extract EXACTLY as written — do not rephrase stems

### Type 2: Bank Soal AI (AI-Generated)
- Source: AI generates new questions based on module topics
- `type`: `"ai_generated"`
- `exam_id`: `bank_soal_ai_NN`
- Confidence may vary: `"definite"`, `"probable"`, or `"uncertain"`
- Reference module.json `exam_focus[]` and `glossary[]` for topic coverage

---

## OUTPUT DESTINATION

Generated `exam_set.json` files go to:
```
app_data/domains/soal/exam_asli/[exam_id].json     ← For asli type
app_data/domains/soal/bank_soal_ai/[exam_id].json  ← For ai_generated type
```

Then register in:
```
app_data/runtime/content_index.kimi.json
```
